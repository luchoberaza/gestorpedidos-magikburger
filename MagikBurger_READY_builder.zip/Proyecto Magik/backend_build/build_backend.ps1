Param(
  [string]$ProjectRoot = (Resolve-Path "$PSScriptRoot\.."),
  [string]$Python = "python"
)

$ErrorActionPreference = "Stop"

Write-Host "== MagikBurger | Build backend EXE (PyInstaller) ==" -ForegroundColor Cyan
Write-Host "ProjectRoot: $ProjectRoot"

$venvDir = Join-Path $ProjectRoot ".build_venv"
$reqFile = Join-Path $PSScriptRoot "requirements.txt"
$specFile = Join-Path $PSScriptRoot "MagikBurgerServer.spec"

if (Test-Path $venvDir) {
  Remove-Item -Recurse -Force $venvDir
}

& $Python -m venv $venvDir

$venvPy = Join-Path $venvDir "Scripts\python.exe"
$venvPip = Join-Path $venvDir "Scripts\pip.exe"

& $venvPy -m pip install --upgrade pip
& $venvPip install -r $reqFile
& $venvPip install pyinstaller

Push-Location $ProjectRoot
try {
  if (Test-Path (Join-Path $ProjectRoot "build")) { Remove-Item -Recurse -Force (Join-Path $ProjectRoot "build") }
  if (Test-Path (Join-Path $ProjectRoot "dist"))  { Remove-Item -Recurse -Force (Join-Path $ProjectRoot "dist")  }

  & $venvPy -m PyInstaller --noconfirm $specFile

  Write-Host ""
  Write-Host "OK. Generado:" -ForegroundColor Green
  Write-Host "  dist\MagikBurgerServer\MagikBurgerServer.exe"
} finally {
  Pop-Location
}
