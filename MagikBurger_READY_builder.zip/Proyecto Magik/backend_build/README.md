# Build del backend (API) sin depender de Python en la PC del cliente

Esto genera `dist\MagikBurgerServer\MagikBurgerServer.exe` (PyInstaller),
y luego el Launcher lo incluye dentro del instalador.

## 1) En tu PC (de build)
- Instalar Python 3.x (solo para compilar)
- Ejecutar:

```powershell
.\backend_build\build_backend.ps1
```

## 2) Luego build del Launcher (instalador final para gente no técnica)
Dentro de `launcher\`:

```bat
build_launcher.bat
```

El instalador final queda en:
`launcher\dist\MagikBurger-Launcher-Setup-*.exe`

## LAN (celulares/tablets)
El backend escucha en 0.0.0.0 (por env MAGIK_HOST) y el puerto 5000.
Desde el celu: `http://IP-DE-LA-PC:5000`
