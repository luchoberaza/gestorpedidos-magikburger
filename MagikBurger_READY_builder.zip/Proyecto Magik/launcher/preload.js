const { contextBridge } = require("electron");
// No toca tu web. Solo placeholder.
contextBridge.exposeInMainWorld("MagikLauncher", {});
