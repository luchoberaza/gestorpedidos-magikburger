const { app, BrowserWindow, dialog } = require("electron");
const path = require("path");
const fs = require("fs");
const { spawn } = require("child_process");
const net = require("net");

// =======================
// Logging (siempre)
// =======================
function getUserDataDir() {
  return app.getPath("userData");
}

function getLogPath() {
  return path.join(getUserDataDir(), "launcher.log");
}

function log(...args) {
  try {
    const dir = getUserDataDir();
    fs.mkdirSync(dir, { recursive: true });
    fs.appendFileSync(
      getLogPath(),
      `[${new Date().toISOString()}] ${args.map(String).join(" ")}\n`,
      "utf-8"
    );
  } catch {}
}

process.on("uncaughtException", (err) => {
  log("uncaughtException:", err?.stack || err?.message || String(err));
});

process.on("unhandledRejection", (reason) => {
  log("unhandledRejection:", reason?.stack || reason?.message || String(reason));
});

// =======================
// Utils puerto
// =======================
function isPortOpen(host, port, timeoutMs = 500) {
  return new Promise((resolve) => {
    const socket = new net.Socket();
    let done = false;

    const finish = (ok) => {
      if (done) return;
      done = true;
      try { socket.destroy(); } catch {}
      resolve(ok);
    };

    socket.setTimeout(timeoutMs);
    socket.once("connect", () => finish(true));
    socket.once("timeout", () => finish(false));
    socket.once("error", () => finish(false));
    socket.connect(port, host);
  });
}

async function waitForPort(host, port, totalMs = 15000) {
  const start = Date.now();
  while (Date.now() - start < totalMs) {
    const ok = await isPortOpen(host, port, 500);
    if (ok) return true;
    await new Promise((r) => setTimeout(r, 250));
  }
  return false;
}

function parseUrl(baseUrl) {
  const u = new URL(baseUrl);
  const host = u.hostname || "127.0.0.1";
  const port = u.port ? parseInt(u.port, 10) : 80;
  return { host, port };
}

// =======================
// Backend autostart
// =======================
let backendProc = null;

function backendDir() {
  // instalado: resources/backend_app
  if (app.isPackaged) return path.join(process.resourcesPath, "backend_app");
  // dev: proyecto un nivel arriba de launcher/
  return path.join(__dirname, "..");
}

function backendAppPyPath() {
  return path.join(backendDir(), "app.py");
}

function backendExePath() {
  return path.join(backendDir(), "MagikBurgerServer.exe");
}

function stopBackend() {
  if (!backendProc) return;
  try {
    log("Stopping backend...");
    backendProc.kill();
  } catch (e) {
    log("stopBackend error:", e?.message || String(e));
  } finally {
    backendProc = null;
  }
}

async function spawnBackend(baseUrl) {
  const { host, port } = parseUrl(baseUrl);

  // Si ya hay algo escuchando, no levantamos otro
  const already = await isPortOpen(host, port, 400);
  if (already) {
    log("Backend ya estaba levantado en", host, port);
    return { ok: true, reused: true };
  }

  const scriptPath = backendAppPyPath();
  const cwd = backendDir();

  log("backendDir:", cwd);
  log("backend app.py:", scriptPath);
  log("target:", baseUrl);

  if (!fs.existsSync(scriptPath)) {
    return { ok: false, error: `No existe app.py en: ${scriptPath}` };
  }

  // Cargar app.py desde archivo y ejecutar app.run sin reloader
  const pyCode = [
    "import importlib.util",
    `p=r'''${scriptPath.replace(/\\/g, "\\\\")}'''`,
    "spec=importlib.util.spec_from_file_location('mb_app', p)",
    "m=importlib.util.module_from_spec(spec)",
    "spec.loader.exec_module(m)",
    `m.app.run(host=r'''${host}''', port=int(${port}), debug=False, use_reloader=False)`
  ].join("; ");

  const candidates = process.platform === "win32"
    ? ["pythonw", "python", "py"]
    : ["python3", "python"];

  let lastErr = null;

  for (const cmd of candidates) {
    try {
      const args = (cmd === "py") ? ["-3", "-c", pyCode] : ["-c", pyCode];

      log("Spawning backend:", cmd, args.join(" "));
      backendProc = spawn(cmd, args, {
        cwd,
        windowsHide: true,
        stdio: "ignore",
        detached: false,
      });

      backendProc.on("error", (e) => {
        lastErr = e;
        log("backendProc error:", e?.message || String(e));
      });

      const up = await waitForPort(host, port, 15000);
      if (up) {
        log("Backend UP:", host, port);
        return { ok: true, reused: false };
      }

      try { backendProc.kill(); } catch {}
      backendProc = null;
      log("Backend no levantó con", cmd);
    } catch (e) {
      lastErr = e;
      log("spawnBackend exception:", e?.message || String(e));
    }
  }

  return { ok: false, error: lastErr ? (lastErr.message || String(lastErr)) : "No se pudo iniciar el backend." };
}

// =======================
// Ventana (IMPORTANTE: guardar referencia global)
// =======================
let mainWindow = null;

function createWindow() {
  const baseUrl = "http://127.0.0.1:5000";

  const win = new BrowserWindow({
    width: 1280,
    height: 800,
    backgroundColor: "#0b0f14",
    show: false,
    webPreferences: {
      preload: path.join(__dirname, "preload.js"),
      contextIsolation: true,
      nodeIntegration: false,
    },
  });

  win.once("ready-to-show", () => win.show());

  // Cargamos la misma web (tu UI)
  win.loadURL(baseUrl);

  win.webContents.on("did-fail-load", async (_e, code, desc) => {
    log("did-fail-load:", code, desc);
    await dialog.showMessageBox(win, {
      type: "error",
      title: "MagikBurger Launcher",
      message:
        "No pude cargar la interfaz.\n\n" +
        `URL: ${baseUrl}\n\n` +
        `Error: (${code}) ${desc}\n\n` +
        "Log:\n" + getLogPath(),
      buttons: ["OK"],
    });
  });

  return win;
}

// =======================
// Main
// =======================
app.whenReady().then(async () => {
  log("=== Launcher start ===");
  log("userData:", getUserDataDir());
  log("log:", getLogPath());
  log("isPackaged:", app.isPackaged);

  // Creamos ventana PRIMERO y la guardamos (para que no muera la app)
  mainWindow = createWindow();

  // Intentamos levantar backend
  const baseUrl = "http://127.0.0.1:5000";
  const started = await spawnBackend(baseUrl);

  if (!started.ok) {
    log("Backend start failed:", started.error || "unknown");
    await dialog.showMessageBox(mainWindow, {
      type: "error",
      title: "MagikBurger Launcher",
      message:
        "El launcher no pudo iniciar el servidor (backend).\n\n" +
        "Causas típicas:\n" +
        "- No hay Python instalado o no está en PATH\n" +
        "- El instalador no incluyó backend_app (app.py/templates/static/db)\n\n" +
        "Detalle:\n" + (started.error || "desconocido") + "\n\n" +
        "Log:\n" + getLogPath(),
      buttons: ["OK"],
    });
  }
});

app.on("before-quit", () => {
  stopBackend();
});

app.on("window-all-closed", () => {
  stopBackend();
  if (process.platform !== "darwin") app.quit();
});

  // Si estamos empaquetados y existe el EXE del backend, lo usamos (no requiere Python instalado).
  const exePath = backendExePath();
  if (app.isPackaged && fs.existsSync(exePath)) {
    try {
      log("Spawning backend EXE:", exePath);

      backendProc = spawn(exePath, [], {
        cwd,
        windowsHide: true,
        stdio: "ignore",
        detached: false,
        env: {
          ...process.env,
          MAGIK_HOST: "0.0.0.0",
          MAGIK_PORT: String(port),
        },
      });

      backendProc.on("error", (e) => {
        lastErr = e;
        log("backendProc error:", e?.message || String(e));
      });

      const ok = await waitPortUp(host, port, 4000);
      if (ok) {
        log("Backend UP (EXE):", host, port);
        return { ok: true };
      }

      log("Backend EXE no levantó el puerto:", host, port);
    } catch (e) {
      lastErr = e;
      log("spawnBackend EXE exception:", e?.message || String(e));
    }
  }

  // Fallback: modo dev o sin EXE -> usar Python (requiere Python instalado)
  // Cargar app.py desde archivo y ejecutar app.run sin reloader
  const pyCode = [
    "import importlib.util",
    `p=r'''${scriptPath.replace(/\\/g, "\\\\")}'''`,
    "spec=importlib.util.spec_from_file_location('mb_app', p)",
    "m=importlib.util.module_from_spec(spec)",
    "spec.loader.exec_module(m)",
    `m.app.run(host=r'''0.0.0.0''', port=int(${port}), debug=False, use_reloader=False)`
  ].join("; ");

  const candidates = process.platform === "win32"
    ? ["pythonw", "python", "py"]
    : ["python3", "python"];
